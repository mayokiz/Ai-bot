# Muse — Android AI Chatbot + Home Screen Widget

An Android Studio project (Kotlin + Jetpack Compose + Android AppWidget) with:
- **Muse Chatbot Screen**: Rule-based keyword matching + live Google Gemini API (`x-goog-api-key`).
- **Real Android Home-Screen Widget**: Shows your latest pinned AI reply / note right on your Android home screen, with an **Open Muse** button.

## How to Run in Android Studio
1. Unzip this folder and open it in **Android Studio** (**File → Open**).
2. Wait for Gradle Sync to finish.
3. Click **Run ▶** on an Android emulator or physical Android phone (USB debugging enabled).
4. In the app, tap **Settings**, paste your Google Gemini API key, and send a message. Tap **Pin to Widget** under any reply.
5. Go to your Android home screen, **long-press an empty space → Widgets → Muse**, and drag the widget onto your home screen!
