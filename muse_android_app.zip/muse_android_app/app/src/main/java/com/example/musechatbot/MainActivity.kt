package com.example.musechatbot

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class ChatMessage(val role: String, val content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MuseApp()
        }
    }
}

@Composable
fun MuseApp() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("muse_prefs", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()

    var apiKey by remember { mutableStateOf(prefs.getString("api_key", "") ?: "") }
    var modelId by remember { mutableStateOf(prefs.getString("model_id", "gemini-2.5-flash") ?: "gemini-2.5-flash") }
    var showSettings by remember { mutableStateOf(false) }
    var inputText by remember { mutableStateOf("") }
    var isSending by remember { mutableStateOf(false) }
    val messages = remember { mutableStateListOf<ChatMessage>() }

    // Warm Muse palette
    val bgCream = Color(0xFFFAF8F5)
    val inkDark = Color(0xFF1F1E1C)
    val userBubble = Color(0xFFEDE8E0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(bgCream)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Muse", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = inkDark)
            TextButton(onClick = { showSettings = !showSettings }) {
                Text(if (showSettings) "Close Settings" else "API Settings", color = inkDark)
            }
        }

        // Settings Card
        if (showSettings) {
            Card(
                modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = apiKey,
                        onValueChange = {
                            apiKey = it
                            prefs.edit().putString("api_key", it.trim()).apply()
                        },
                        label = { Text("Gemini API Key") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = modelId,
                        onValueChange = {
                            modelId = it
                            prefs.edit().putString("model_id", it.trim()).apply()
                        },
                        label = { Text("Model ID") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        }

        // Chat List
        LazyColumn(
            modifier = Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(messages) { msg ->
                val isUser = msg.role == "user"
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                ) {
                    Surface(
                        color = if (isUser) userBubble else Color.White,
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = msg.content,
                            modifier = Modifier.padding(12.dp),
                            color = inkDark,
                            fontSize = 15.sp
                        )
                    }
                    if (!isUser) {
                        TextButton(onClick = {
                            prefs.edit().putString("pinned_text", msg.content).apply()
                            MuseWidgetProvider.updateAllWidgets(context)
                        }) {
                            Text("Pin to Home Widget", fontSize = 12.sp, color = Color(0xFF6E685F))
                        }
                    }
                }
            }
        }

        // Input Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask Muse anything...") },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                singleLine = true
            )
            Button(
                onClick = {
                    val prompt = inputText.trim()
                    if (prompt.isEmpty() || isSending) return@Button
                    inputText = ""
                    messages.add(ChatMessage("user", prompt))
                    isSending = true

                    scope.launch {
                        val reply = if (apiKey.isBlank()) {
                            getRuleReply(prompt)
                        } else {
                            callGeminiApi(messages.toList(), apiKey, modelId)
                        }
                        messages.add(ChatMessage("assistant", reply))
                        isSending = false
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2C2A27)),
                shape = RoundedCornerShape(24.dp)
            ) {
                Text(if (isSending) "..." else "Send")
            }
        }
    }
}

fun getRuleReply(text: String): String {
    val lower = text.lowercase()
    return when {
        "hello" in lower || "hi" in lower -> "Hi! Open API Settings at the top to add your Gemini key, or ask about 'tokens'."
        "token" in lower -> "A token is a small piece of text (~4 characters) that a language model reads and predicts."
        else -> "Rule-based mode: add a Gemini API key in API Settings for full AI answers!"
    }
}

suspend fun callGeminiApi(history: List<ChatMessage>, apiKey: String, modelId: String): String =
    withContext(Dispatchers.IO) {
        try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$modelId:generateContent")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("x-goog-api-key", apiKey)
                doOutput = true
            }

            val contents = JSONArray()
            for (msg in history) {
                val role = if (msg.role == "assistant") "model" else "user"
                val part = JSONObject().put("text", msg.content)
                contents.put(JSONObject().put("role", role).put("parts", JSONArray().put(part)))
            }
            val body = JSONObject().put("contents", contents)

            conn.outputStream.use { it.write(body.toString().toByteArray()) }

            val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
            val responseText = stream.bufferedReader().readText()
            val json = JSONObject(responseText)

            if (conn.responseCode !in 200..299) {
                val errMsg = json.optJSONObject("error")?.optString("message") ?: "HTTP ${conn.responseCode}"
                return@withContext "API error: $errMsg"
            }

            json.getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
                .getJSONObject(0)
                .getString("text")
        } catch (e: Exception) {
            "Network error: ${e.message}"
        }
    }
